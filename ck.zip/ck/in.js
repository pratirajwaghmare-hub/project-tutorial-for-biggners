document.write("html script tag");
document.write("thanks fot watching");