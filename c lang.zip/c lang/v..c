#include<stdio.h>
#include<conio.h>
int main() {
	int i,j,n =7;
	printf("\n\n\n\n\n\n");
	for(i=1;i<=n;i++){
		printf("  ");
		for(j=1;j<=n*2;j++){
			if(j<=i || j>n*2-i){
				printf("*");
			}
			else{
				printf(" ");
			}
		}
		printf("\n");
	}
  return 0;  
}





