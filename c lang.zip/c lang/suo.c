#include<stdio.h>
#include<conio.h>
int main() {
	int i,j,n = 0,b = 1, num;
	printf("Enter the number of terms : ");
	scanf("%d",&i);
    printf("Fibonacci Series : ");
    for(j=0;j<i;j++){
    	if(j<=1){
    		num = j;
		}
		else{
			num = n + b;
			n = b;
			b = num;
		}
		printf("%d",num);
	}
	
  return 0;  
}
//like and subscribed



