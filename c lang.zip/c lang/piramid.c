#include<stdio.h>
#include<conio.h>
#include<math.h>
int main(){
  int s =9;
  int o =1;
  int a,b,c;
  for(a=1;a<=s;a++){
  	for(b=s-1;b>=a;b--){
  		printf(" ");
	  }
	for(c=0; c<o; c++){
		printf("%d",a);
	}
	o+=2;
	printf("\n");
  }
  
  return 0;  
}




