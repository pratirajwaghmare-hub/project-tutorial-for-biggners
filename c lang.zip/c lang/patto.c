#include<stdio.h>
#include<conio.h>
void main(){
	int rows;
	int i,j;
	printf("Number of Rows:");
	scanf("%d",&rows);
	for(i=1;i<=rows;i++){
		for(j=1;j<=i;j++){
			printf("%d",i);
		}
		printf("\n");
	}
	getch();
}
