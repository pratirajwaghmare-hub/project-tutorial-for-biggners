#include<stdio.h>
#include<conio.h>
void main(){
  int i,n;
  int s1=0,s2=1;
  int nextTerm=s1+s2;
  printf("Enter the No. of terms:");
  scanf("%d",&n);
  printf("Fibonacci Series:%d,%d",s1,s2,"Thanks for watching");
  for(i=3; i<=n; i++){
  	printf("%d",nextTerm,"Thanks for watching");
  	s1 = s2;
  	s2 = nextTerm;
  	nextTerm = s1+s2;
  }
  getch();
}
