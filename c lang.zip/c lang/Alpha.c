#include<stdio.h>
#include<conio.h>
void main(){
	int i;
	printf(" Thanks for watching Alphabet A to Z: \n");
	for(i=65;i<=90;i++){
		printf("%c",i);
	}
	printf("\n");
	printf("Alphabet a to z:\n");
	for(i=97;i<=122;i++){
		printf("%c",i);
	}
	getch();
}
