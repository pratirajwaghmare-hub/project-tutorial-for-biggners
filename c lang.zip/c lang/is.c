#include<stdio.h>
#include<conio.h>
void main(){
  char c;
  printf(" Thanks for watching Enter your any character:");
  scanf("%c",&c);
  if(c == 'A' || c == 'E' || c == 'I' || c == 'O' || c =='U'||c == 'a' || c == 'e' || c == 'i' || c == 'o' || c =='u'){
  	printf("character %c is a Vowel \n",c);
  }
  else{
  	printf("Character %c is consonent",c);
  }
  getch();
}
