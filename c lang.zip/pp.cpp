#include<iostream>
using namespace std;
int main () {
   int like,count;
   int share,follow;
   cout<<"Enter a number:\n";/*c ++ project tutorial*/
   cin >> like;
   cout<<"type prime number: "<<like<<endl;
   for(share=2;share<=like;share++){
   	count=0;
   	for(follow=2;follow<share;follow++){
   		if(share%follow==0)
   		  count++;
	   }
	   if(count == 0){
	   	cout << share<< "\n";
	   }
   }
    return 0;
	}

